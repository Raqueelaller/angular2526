import { Component } from '@angular/core';

@Component({
  selector: 'app-add-personaje',
  // imports: [],
  templateUrl: './add-personaje.html',
  styleUrl: './add-personaje.css',
  standalone:false
})
export class AddPersonajeComponet {

}
