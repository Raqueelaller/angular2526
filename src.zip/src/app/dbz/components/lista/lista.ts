import { Component } from '@angular/core';
import { ListaComponents } from '../../../heroes/components/lista/lista';

@Component({
  selector: 'app-lista',
  // imports: [],
  templateUrl: './lista.html',
  styleUrl: './lista.css',
  standalone:false
})
export class ListaComponent {

}
